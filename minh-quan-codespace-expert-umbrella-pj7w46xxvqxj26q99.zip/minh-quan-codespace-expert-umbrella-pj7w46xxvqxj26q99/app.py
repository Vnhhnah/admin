from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_socketio import SocketIO, emit
import portpicker
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///admin.db'
db = SQLAlchemy(app)

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

# Sample data for orders and vehicles (in a real application, this would come from a database)
orders = [
    {"id": 1, "status": "Pending", "tracking_code": None},
    {"id": 2, "status": "Confirmed", "tracking_code": "TRK12345"}
]

vehicles = [
    {"id": 1, "status": "Available"},
    {"id": 2, "status": "Assigned"}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/orders')
def orders_page():
    return render_template('orders.html')

@app.route('/vehicles')
def vehicles_page():
    return render_template('vehicles.html')

@app.route('/tracking')
def tracking_page():
    return render_template('tracking.html')

@app.route('/send_gps')
def send_gps():
    return render_template('send_gps.html')

@app.route('/api/orders', methods=['GET'])
def get_orders():
    return jsonify(orders)

@app.route('/api/orders/<int:order_id>/confirm', methods=['POST'])
def confirm_order(order_id):
    for order in orders:
        if order['id'] == order_id:
            order['status'] = 'Confirmed'
            order['tracking_code'] = f'TRK{order_id:05d}'
            return jsonify({"message": "Order confirmed", "order": order})
    return jsonify({"message": "Order not found"}), 404

@app.route('/api/vehicles', methods=['GET'])
def get_vehicles():
    return jsonify(vehicles)

@app.route('/api/vehicles/<int:vehicle_id>/assign', methods=['POST'])
def assign_vehicle(vehicle_id):
    for vehicle in vehicles:
        if vehicle['id'] == vehicle_id:
            vehicle['status'] = 'Assigned'
            return jsonify({"message": "Vehicle assigned", "vehicle": vehicle})
    return jsonify({"message": "Vehicle not found"}), 404

@socketio.on('gps_data')
def handle_gps_data(data):
    emit('update_location', data, broadcast=True)

@app.route('/api/available_vehicles')
def available_vehicles():
    # Replace with your logic to fetch available vehicles
    vehicles = [
        {'id': 1, 'name': 'Xe 1'},
        {'id': 2, 'name': 'Xe 2'},
        {'id': 3, 'name': 'Xe 3'},
    ]
    return jsonify({'vehicles': vehicles})

@app.route('/api/order_addresses')
def order_addresses():
    # Replace with your logic to fetch sender and recipient addresses
    sender_address = "123 Sender St, City, Country"
    recipient_address = "456 Recipient Ave, City, Country"
    return jsonify({'senderAddress': sender_address, 'recipientAddress': recipient_address})
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password_hash, password):
            session['admin_id'] = admin.id
            flash('Đăng nhập thành công!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Tên đăng nhập hoặc mật khẩu không đúng!', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = generate_password_hash(password)
        new_admin = Admin(username=username, password_hash=password_hash)
        try:
            db.session.add(new_admin)
            db.session.commit()
            flash('Đăng ký thành công!', 'success')
            return redirect(url_for('login'))
        except:
            flash('Tên đăng nhập đã tồn tại!', 'danger')
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('admin_id', None)
    flash('Đã đăng xuất!', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
    port = portpicker.pick_unused_port()
    socketio.run(app, port=port, debug=True)