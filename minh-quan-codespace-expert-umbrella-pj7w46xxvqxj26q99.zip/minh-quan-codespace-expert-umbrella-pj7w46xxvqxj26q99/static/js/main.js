const orders = [
    {id: 1, status: 'Pending', tracking_code: null},
    {id: 2, status: 'Confirmed', tracking_code: 'TRK12345'}
];

function loadOrders() {
    const orderTableBody = document.getElementById('order-table-body');
    orderTableBody.innerHTML = '';
    orders.forEach(order => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${order.id}</td>
            <td>${order.status}</td>
            <td>${order.tracking_code || 'N/A'}</td>
            <td>
                <button class="btn btn-primary" onclick="confirmOrder(${order.id})">Xác nhận</button>
            </td>
        `;
        orderTableBody.appendChild(row);
    });
}

function confirmOrder(orderId) {
    alert(`Order ${orderId} confirmed!`);
    loadOrders();
}

const vehicles = [
    {id: 1, status: 'Available'},
    {id: 2, status: 'Assigned'}
];

function loadVehicles() {
    const vehicleTableBody = document.getElementById('vehicle-table-body');
    vehicleTableBody.innerHTML = '';
    vehicles.forEach(vehicle => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${vehicle.id}</td>
            <td>${vehicle.status}</td>
            <td>
                <button class="btn btn-primary" onclick="assignVehicle(${vehicle.id})">Giao nhiệm vụ</button>
            </td>
        `;
        vehicleTableBody.appendChild(row);
    });
}

function assignVehicle(vehicleId) {
    alert(`Vehicle ${vehicleId} assigned!`);
    loadVehicles();
}

function sendGPSData() {
    if (navigator.geolocation) {
        navigator.geolocation.watchPosition(function(position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            socket.emit('gps_data', {id: 'vehicle_1', lat: lat, lon: lon});
        }, function(error) {
            console.error('Error getting location: ', error);
        }, {
            enableHighAccuracy: true,
            maximumAge: 0,
            timeout: 5000
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('order-table-body')) {
        loadOrders();
    }
    if (document.getElementById('vehicle-table-body')) {
        loadVehicles();
    }
    if (document.getElementById('map')) {
        sendGPSData();
    }
});